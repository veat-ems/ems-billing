<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Variablegraphical extends CI_Controller {

	function __construct(){
		parent::__construct();		
		$this->load->model('model_variablegraphical');
		if($this->session->userdata('id_jenis_user') <> '1')
		{
			redirect('login');
		}
	}
	
    public function index() {
		$d['title'] = 'VARIABLE-GRAPHICAL';
		$d['judul'] = 'Login Multiuser Codeigniter dengan Mysql';
		$d['username'] = $this->session->userdata('username');
		$d['level'] = $this->session->userdata('level');
		$d['nama'] = $this->session->userdata('nama');
		$d['email'] = $this->session->userdata('email');
		$d['avatar'] = $this->session->userdata('avatar');
		$d['background'] = $this->session->userdata('background');
		$d['page'] = 'admin';
		$d['data_meter'] = $this->model_variablegraphical->getdata('data_meter')->result();
		$d['jml_meter'] = $this->model_variablegraphical->count_data('data_meter');	
        $this->template->display('variablegraphical',$d);
    }
	
	
	
    public function view($id) {
		$d['title'] = 'VARIABLE-GRAPHICAL';
		$d['judul'] = 'Login Multiuser Codeigniter dengan Mysql';
		$d['username'] = $this->session->userdata('username');
		$d['level'] = $this->session->userdata('level');
		$d['nama'] = $this->session->userdata('nama');
		$d['email'] = $this->session->userdata('email');
		$d['avatar'] = $this->session->userdata('avatar');
		$d['background'] = $this->session->userdata('background');
		$d['page'] = 'admin';
		$d['data_meter'] = $this->model_variablegraphical->getdata('data_meter')->result();
		$d['jml_meter'] = $this->model_variablegraphical->count_data('data_meter');	
        $this->template->display('variablegraphicalview',$d);
    }
	
	public function datameter()
	{
		
		$id = $this->input->post('id');
		
			// $id = "17. LINE 7";
			$data = array();
			$row = array();
			
			/*				
			$id_counter = $this->model_variablegraphical->getcounter_id('counter2',$id);			
			$dtmeter = $this->model_variablegraphical->dt_meter($id)->row();		
			$dtcounter = $this->model_variablegraphical->dt_counter2($id_counter)->row();
			*/
			$dtmeter 			= $this->model_variablegraphical->dt_meter($id)->row();	
			$dtcounter 			= $this->model_variablegraphical->dt_counter2($id)->row();
			
			if($dtcounter=='' or $dtcounter==null or !$dtcounter){
				$row['id_counter'] = '0';
				$row['date_time']  = '0000-00-00 00:00:00';				
				$row['id'] 		   = $id;			
				$row['type'] 	   = $dtmeter->type;			
				$row['com'] 	   = $dtmeter->com;			
				$row['modbus'] 	   = $dtmeter->modbus;			
				$row['status'] 	   = 'SIMULATION';			
				$row['v1'] 		   = 0;		
				$row['v2'] 		   = 0;		
				$row['v3'] 		   = 0;		
				$row['v12'] 	   = 0;		
				$row['v23'] 	   = 0;		
				$row['v31'] 	   = 0;		
				$row['i1'] 		   = 0;		
				$row['i2'] 		   = 0;		
				$row['i3'] 		   = 0;		
				$row['inet'] 	   = 0;		
  				$row['watt1']	   = 0;		
				$row['watt2'] 	   = 0;		
				$row['watt3'] 	   = 0;	
				$row['watt'] 	   = 0;				
				$row['va1'] 	   = 0;		
				$row['va2'] 	   = 0;		
				$row['va3'] 	   = 0;		
				$row['va'] 		   = 0;			
				$row['freq'] 	   = 0;		
				$row['pf1'] 	   = 0;		
				$row['pf2'] 	   = 0;		
				$row['pf3'] 	   = 0;			
				$row['kwh_exp']    = 0;		
				$row['kwh_imp']    = 0;		
				$row['kvarh_exp']  = 0;		
				$row['kvarh_imp']  = 0;		
				$row['kvah'] 	   = 0;		
				$row['thd_v1'] 	   = 0;		
				$row['thd_v2'] 	   = 0;		
				$row['thd_v3'] 	   = 0;			
				$row['thd_i1'] 	   = 0;		
				$row['thd_i2'] 	   = 0;		
				$row['thd_i3'] 	   = 0;			
				$row['kwh1'] 	   = 0;		
				$row['kwh2'] 	   = 0;		
				$row['kwh'] 	   = 0;
				
				$data[] = $row;
			
			}
			else{
				
				$row['id_counter'] = $dtcounter->id_counter;
				$row['date_time']  = $dtcounter->date_time;			
				$row['id'] 		   = $id;			
				$row['type'] 	   = $dtcounter->type;			
				$row['com'] 	   = $dtcounter->com;			
				$row['modbus'] 	   = $dtcounter->modbus;			
				$row['status'] 	   = $dtcounter->status;		
				$row['v1'] 		   = $dtcounter->v1;		
				$row['v2'] 		   = $dtcounter->v2;		
				$row['v3'] 		   = $dtcounter->v3;		
				$row['v12'] 	   = $dtcounter->v12;		
				$row['v23'] 	   = $dtcounter->v23;		
				$row['v31'] 	   = $dtcounter->v31;		
				$row['i1'] 		   = $dtcounter->i1;		
				$row['i2'] 		   = $dtcounter->i2;		
				$row['i3'] 		   = $dtcounter->i3;		
				$row['inet'] 	   = $dtcounter->inet;		
  				$row['watt1']	   = $dtcounter->watt1;		
				$row['watt2'] 	   = $dtcounter->watt2;		
				$row['watt3'] 	   = $dtcounter->watt3;	
				$row['watt'] 	   = $dtcounter->watt/1000;				
				$row['va1'] 	   = $dtcounter->va1;		
				$row['va2'] 	   = $dtcounter->va2;		
				$row['va3'] 	   = $dtcounter->va3;		
				$row['va'] 		   = $dtcounter->va/1000;			
				$row['freq'] 	   = $dtcounter->freq;		
				$row['pf1'] 	   = $dtcounter->pf1;		
				$row['pf2'] 	   = $dtcounter->pf2;		
				$row['pf3'] 	   = $dtcounter->pf3;			
				$row['kwh_exp']    = $dtcounter->kwh_exp/1000;		
				$row['kwh_imp']    = $dtcounter->kwh_imp/1000;		
				$row['kvarh_exp']  = $dtcounter->kvarh_exp/1000;		
				$row['kvarh_imp']  = $dtcounter->kvarh_imp/1000;		
				$row['kvah'] 	   = $dtcounter->kvah;		
				$row['thd_v1'] 	   = $dtcounter->thd_v1;		
				$row['thd_v2'] 	   = $dtcounter->thd_v2;		
				$row['thd_v3'] 	   = $dtcounter->thd_v3;			
				$row['thd_i1'] 	   = $dtcounter->thd_i1;		
				$row['thd_i2'] 	   = $dtcounter->thd_i2;		
				$row['thd_i3'] 	   = $dtcounter->thd_i3;			
				$row['kwh1'] 	   = $dtcounter->kwh1;		
				$row['kwh2'] 	   = $dtcounter->kwh2;		
				$row['kwh'] 	   = $dtcounter->kwh;
				
				
				$row['v1_formatted'] 		= number_format($dtcounter->v1, 2);		
				$row['v2_formatted'] 		= number_format($dtcounter->v2, 2);		
				$row['v3_formatted'] 		= number_format($dtcounter->v3, 2);		
				$row['v12_formatted'] 	   	= number_format($dtcounter->v12, 2);		
				$row['v23_formatted'] 	   	= number_format($dtcounter->v23, 2);		
				$row['v31_formatted'] 	   	= number_format($dtcounter->v31, 2);		
				$row['i1_formatted'] 		= number_format($dtcounter->i1, 2);		
				$row['i2_formatted'] 		= number_format($dtcounter->i2, 2);		
				$row['i3_formatted'] 		= number_format($dtcounter->i3, 2);		
				$row['inet_formatted'] 	   	= number_format($dtcounter->inet, 2);		
				$row['watt1_formatted']	   	= number_format($dtcounter->watt1, 2);		
				$row['watt2_formatted'] 	= number_format($dtcounter->watt2, 2);		
				$row['watt3_formatted'] 	= number_format($dtcounter->watt3, 2);	
				$row['watt_formatted'] 	   	= number_format($dtcounter->watt/1000, 2);				
				$row['va1_formatted'] 	   	= number_format($dtcounter->va1, 2);		
				$row['va2_formatted'] 	   	= number_format($dtcounter->va2, 2);		
				$row['va3_formatted'] 	   	= number_format($dtcounter->va3, 2);		
				$row['va_formatted'] 		= number_format($dtcounter->va/1000, 2);			
				$row['freq_formatted'] 	   	= number_format($dtcounter->freq, 2);		
				$row['pf1_formatted'] 	   	= number_format($dtcounter->pf1, 2);		
				$row['pf2_formatted'] 	   	= number_format($dtcounter->pf2, 2);		
				$row['pf3_formatted'] 	  	= number_format($dtcounter->pf3, 2);			
				$row['kwh_exp_formatted']   = number_format($dtcounter->kwh_exp/1000, 2);		
				$row['kwh_imp_formatted']   = number_format($dtcounter->kwh_imp/1000, 2);		
				$row['kvarh_exp_formatted'] = number_format($dtcounter->kvarh_exp/1000, 2);		
				$row['kvarh_imp_formatted'] = number_format($dtcounter->kvarh_imp/1000, 2);		
				$row['kvah_formatted'] 	   	= number_format($dtcounter->kvah, 2);		
				$row['thd_v1_formatted'] 	= number_format($dtcounter->thd_v1, 2);		
				$row['thd_v2_formatted'] 	= number_format($dtcounter->thd_v2, 2);		
				$row['thd_v3_formatted'] 	= number_format($dtcounter->thd_v3, 2);			
				$row['thd_i1_formatted'] 	= number_format($dtcounter->thd_i1, 2);		
				$row['thd_i2_formatted'] 	= number_format($dtcounter->thd_i2, 2);		
				$row['thd_i3_formatted'] 	= number_format($dtcounter->thd_i3, 2);			
				$row['kwh1_formatted'] 	   	= number_format($dtcounter->kwh1, 2);		
				$row['kwh2_formatted'] 	   	= number_format($dtcounter->kwh2, 2);		
				$row['kwh_formatted'] 	   	= number_format($dtcounter->kwh, 2);
								
				
				//$data[] = $dtcounter;
				$data[] = $row;
			}

			
		$output = array($data
				);
		//output to json format
		echo json_encode($data);
	}


}